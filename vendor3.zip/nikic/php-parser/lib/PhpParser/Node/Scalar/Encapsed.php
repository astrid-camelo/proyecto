<?php declare(strict_types=1);

namespace PhpParser\Node\Scalar;

require __DIR__ . '/InterpolatedString.php';

if (false) {
    // For classmap-authoritative support.
    class Encapsed extends InterpolatedString {
    }
}
