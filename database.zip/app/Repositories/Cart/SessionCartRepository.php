<?php

namespace App\Repositories\Cart;

use App\Models\Product;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Session;
use Exception;
use App\Traits\ProductCurrencyFormatter;

class SessionCartRepository implements CartRepositoryInterface
{
    use ProductCurrencyFormatter;

    const SESSION = 'cart';

    public function __construct()
    {
       if(!Session::has(self::SESSION))
       {
        Session::put(self::SESSION, collect());
       }
    }

    public function add(Product $product, int $quantify): void
    {
        $cart = $this->getCart();

        if($cart->has($product->id))
        {
            $cart->get($product->id)['quantity'] += $quantify;
        } else {
            $cart->put($product->id, [
            'product' => $product,
            'quantify' => $quantify, 
            ]);
        }

        $this->updateCart($cart);
    }

    /**
     * @throws Exception
     */

     public function increment(Product $product): void
     {
         $cart = $this->getCart();
         if ($cart->has($product->id))
         {
             if (data_get($cart->get($product->id), 'quantity') >= $product->stock)
             {
                 throw new Exception('No hay suficiente stock para incrementar la cantidad de ' . $product->name);
             }
     
             $productInCart = $cart->get($product->id);
     
             // Asegurar que 'quantity' existe
             if (!isset($productInCart['quantity'])) {
                 $productInCart['quantity'] = 0;
             }
     
             $productInCart['quantity']++;
     
             $cart->put($product->id, $productInCart);
             $this->updateCart($cart);
         }
     }
     

    public function decrement(int $productId): void
{
    $cart = $this->getCart();
    if ($cart->has($productId)) 
    {
        $productInCart = $cart->get($productId);

        // Validar que quantity exista, si no, asignarlo a 1
        if (!isset($productInCart['quantity'])) {
            $productInCart['quantity'] = 1;
        }

        $productInCart['quantity']--;

        $cart->put($productId, $productInCart);

        // Si la cantidad es menor o igual a 0, eliminamos el producto
        if (data_get($cart->get($productId), 'quantity') <= 0) {
            $cart->forget($productId);
        }
        
        $this->updateCart($cart);
    }
}


    public function remove(int $productId): void
    {
        $cart = $this->getCart();

        $cart->forget($productId);
        
        $this->updateCart($cart);

    }

    public function getTotalQuantityForProduct(Product $product): int
    {
        $cart = $this->getCart();
        if($cart->has($product->id))
        {
            return (int) data_get($cart->get($product->id), key: 'quantity');
        }

        return 0;
    }

    public function getTotalCostForProduct(Product $product, bool $formatted): float|string
{
    $cart = $this->getCart();
    $total = 0;
    if ($cart->has($product->id))
    {
        $total = data_get($cart->get($product->id), key: 'quantity') * $product->price;
    }
    return $formatted ? '$' . number_format($total, 0, ',', '.') : $total;
}


    public function getTotalQuantity(): int
    {
        $cart = $this->getCart();

        return $cart->sum(callback: 'quantity');
    }

    public function getTotalCost(bool $formatted): float|string
{
    $cart = $this->getCart();
    $total = $cart->sum(function ($item)
    {
        return data_get($item, key: 'quantity') * data_get($item, key: 'product.price');
    });

    return $formatted ? '$' . number_format($total, 0, ',', '.') : $total;
}


    public function hasProduct(Product $product): bool
    {
        $cart = $this->getCart();

        return $cart->has($product->id);
    }

    public function getCart(): Collection
    {
        return Session::get(self::SESSION, collect());
    }

    public function isEmpty(): bool
    {
        return $this->getTotalQuantity() === 0;
    }

    public function clear(): void
    {
        Session::forget(keys:self::SESSION);
    }

    public function updateCart(Collection $cart): void 
    {
        Session::put(self::SESSION, $cart);
    }

}