<?php

namespace App\Repositories\Category;

use App\Models\Category;
use App\Traits\CRUDOperations;
use Exception;

class EloquentCategoryRepository implements CategoryRepositoryInterface
{
    use CRUDOperations;

    protected string $model = Category::class;

   /**
 * @throws Exception
 */
protected function deleteChecks(): void
{
    if ($category->products()->exists()) {
        throw new Exception('No se puede eliminar porque tiene vinos asociados');
    }
}

}