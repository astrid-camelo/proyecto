<?php

namespace App\Repositories\Category;

use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\Category;

interface CategoryRepositoryInterface
{
    public function model(?string $slug = null): Category;

    public function paginate(array $counts = [], array $relationships = [], int $perPage = 10): LengthAwarePaginator;

    public function create(array $data): Category;

    public function update(array $data, Category $category): Category;

    public function delete(Category $category): ?bool;
}
