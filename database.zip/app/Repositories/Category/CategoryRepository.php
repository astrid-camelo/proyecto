<?php

namespace App\Repositories\Category;

use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\Category;

class CategoryRepository implements CategoryRepositoryInterface
{
    public function model(?string $slug = null): Category
    {
        return $slug 
            ? Category::whereSlug($slug)->firstOrFail() 
            : new Category();
    }

    public function paginate(array $counts = [], array $relationships = [], int $perPage = 10): LengthAwarePaginator
{
    return Category::query()
        ->with($relationships) // Relación cargada
        ->withCount($counts)   // Conteo de relación
        ->paginate($perPage);  // Paginación
}


    public function create(array $data): Category
    {
        return Category::create($data);
    }

    public function update(array $data, Category $category): Category
    {
        $category->update($data);
        return $category;
    }

    public function delete(Category $category): ?bool
    {
        return $category->delete();
    }
}
