<?php

namespace App\Repositories\Product;

use App\Models\Product;
use App\Traits\CRUDOperations;
use App\Services\UploadService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\LengthAwarePaginator;

class EloquentProductRepository implements ProductRepositoryInterface
{
    use CRUDOperations;

    protected string $model = Product::class;

    /**
     * Obtener el modelo con un slug o una instancia nueva.
     *
     * @param string|null $slug
     * @return Model
     */
    public function model(?string $slug = null): Model
    {
        if ($slug) {
            return $this->model::where('slug', $slug)->firstOrFail();
        }

        return app($this->model);
    }

    /**
     * Paginar productos con relaciones y conteos.
     *
     * @param array $params
     * @param array $validations
     * @param int $perPage
     * @return LengthAwarePaginator
     */
    public function machine(array $params = [], array $validations = [], int $perPage = 10): LengthAwarePaginator
    {
        return $this->model::query()
            ->with($params['relationships'] ?? [])
            ->withCount($validations['counts'] ?? [])
            ->paginate($perPage);
    }

    /**
     * Crear un nuevo producto.
     *
     * @param array $data
     * @return Model
     */
    public function create(array $data): Model
    {
        if (isset($data['image'])) {
            $data['image'] = UploadService::upload($data['image'], strtolower(class_basename($this->model)));
        }

        return $this->model::create($data);
    }

    /**
     * Actualizar un producto existente.
     *
     * @param array $data
     * @param int $id
     * @return Model
     */
    public function update(array $data, int $id): Model
    {
        $model = $this->model::findOrFail($id);

        if (isset($data['image'])) {
            UploadService::delete($model->image);
            $data['image'] = UploadService::upload($data['image'], strtolower(class_basename($this->model)));
        }

        $model->update($data);

        return $model;
    }

    /**
     * Eliminar un producto existente.
     *
     * @param int $id
     * @return bool|null
     */
    public function delete(int $id): ?bool
    {
        $model = $this->model::findOrFail($id);

        if (method_exists($this, 'deleteChecks')) {
            $this->deleteChecks($model);
        }

        if (method_exists($model, 'products')) {
            $model->products()->delete();
        }

        UploadService::delete($model->image);

        return $model->delete();
    }
}
