<?php

namespace App\Repositories\Product;

interface ProductRepositoryInterface
{
    public function model(?string $slug = null);

    public function machine(array $params = [], array $validations = [], int $perPage = 10);

    public function create(array $data);

    public function update(array $data, int $id);

    public function delete(int $id);
}
