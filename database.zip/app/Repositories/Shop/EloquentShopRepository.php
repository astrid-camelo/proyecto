<?php

namespace App\Repositories\Shop;

use App\Models\Product;
use Illuminate\Pagination\LengthAwarePaginator;

class EloquentShopRepository implements ShopRepositoryInterface
{
    public function paginate(int $perPage = 15): LengthAwarePaginator
    {
        return Product::paginate($perPage); // Ajusta según tu modelo
    }

    public function find(int $id): Product
    {
        return Product::findOrFail($id); // Usa findOrFail para devolver error si no lo encuentra
    }
}

