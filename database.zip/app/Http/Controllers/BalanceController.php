<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;

class BalanceController extends Controller
{
public function addBalance(Request $request): RedirectResponse
{
    $request->validate([
        'amount' => 'required|numeric|min:1000', // Ajustado para valores en COP
    ]);

    $user = auth()->user();
    $user->balance += $request->input('amount');
    $user->save();

    return redirect()->route('balance.view')->with('success', 'Saldo añadido correctamente. Saldo total: ' . number_format($user->balance, 0, ',', '.'));
}


}
