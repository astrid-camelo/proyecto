<?php

namespace App\Http\Controllers;

use App\Repositories\Shop\ShopRepositoryInterface;
use Illuminate\Http\RedirectResponse;
use App\Services\Cart;
use App\Traits\CartActions;
use Illuminate\View\View;
use Illuminate\Http\Request;
use App\Models\Product;


class ShopController extends Controller
{
    use CartActions;
    private ShopRepositoryInterface $repository;
    private Cart $cart;

    public function __construct(ShopRepositoryInterface $repository, Cart $cart)
    {
        $this->repository = $repository;
        $this->cart = $cart;
    }

    // Ejemplo de uso de las propiedades
    public function index(): View
{      
    $products = $this->repository->paginate();

    // Formatear precios en COP
   /* foreach ($products as $product) {
        $product->price = number_format($product->price, 0, ',', '.');
    }
*/
    return view('shop.index', compact('products'));
}


    public function addToCart(): RedirectResponse
    {
        $this->addProductToCart();
        return redirect()->route('shop.index');
    }

    public function increment(): RedirectResponse
    {
        $this->incrementProductQuantify();
        return redirect()->route('shop.index');
    }

    public function decrement(): RedirectResponse
    {
        $this->decrementProductQuantity();
        return redirect()->route('shop.index');
    }

    public function remove(): RedirectResponse
    {
        $this->removeProduct();
        return redirect()->route('shop.index');
    }

public function search(Request $request): View
{
    $query = Product::query();

    if ($request->filled('name')) {
        $query->where('name', 'LIKE', '%' . $request->name . '%');
    }

    if ($request->filled('category')) {
        $query->whereHas('category', fn($q) => $q->where('name', 'LIKE', '%' . $request->category . '%'));
    }
 
    if ($request->filled('min_price') && $request->filled('max_price')) {
        $query->whereBetween('price', [$request->min_price, $request->max_price]);
    }

    $products = $query->paginate(12);

    return view('shop.index', compact('products'));
}


    
}
