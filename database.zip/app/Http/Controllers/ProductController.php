<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use App\Models\Product;
use App\Repositories\Product\ProductRepositoryInterface;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Illuminate\Http\Request;
use App\Services\UploadService;



class ProductController extends Controller
{
    private ProductRepositoryInterface $repository;

    public function __construct(ProductRepositoryInterface $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Mostrar una lista de productos.
     *
     * @return View
     */
    public function index(): View
    {
        return view('product.index', [
            'products' => $this->repository->paginate(
                relationships: ['category']
            ),
        ]);
    }

    /**
     * Eliminar un producto existente.
     *
     * @param int $id
     * @return RedirectResponse
     */
    public function delete(string|int $id): ?bool
    {
        $model = is_numeric($id)
            ? $this->model::findOrFail($id)  // Buscar por ID si es numérico
            : $this->model::where('slug', $id)->firstOrFail(); // Buscar por slug si es texto
    
        return $model->delete();
    }

    public function destroy(Product $product): RedirectResponse
    {
        $this->repository->delete($product->id);
    
        return redirect()
            ->route('product.index')
            ->with('success', 'Producto eliminado correctamente.');
    }

    public function create(): View
{
    return view('product.create', [
        'wine' => $this->repository->model(),
        'action' => route('product.store'),
        'method' => 'POST',
        'submit' => 'Crear',
    ]);
}

public function store(Request $request): RedirectResponse
{
    // Validar los datos del formulario
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'category_id' => 'required|exists:categories,id',
        'year' => 'required|integer|min:1900|max:' . date('Y'),
        'price' => 'required|numeric|min:0',
        'stock' => 'required|integer|min:0',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        'description' => 'nullable|string',
    ]);

    // Formatear precio en COP
    $validated['price'] = number_format($validated['price'], 0, ',', '.');

    // Manejar la carga de la imagen si existe
    if ($request->hasFile('image')) {
        $validated['image'] = UploadService::upload($request->file('image'), 'products');
    }

    // Crear el producto
    Product::create($validated);

    // Redirigir con mensaje de éxito
    return redirect()
        ->route('product.index')
        ->with('success', 'Producto creado exitosamente con precio en COP.');
}
  

    public function edit(Product $product): View
{
    return view('product.edit', [
        'product' => $product,
        'action' => route('products.update', $product),
        'method' => 'PUT',
        'submit' => 'Actualizar',
    ]);
}

public function update(Request $request, Product $product): RedirectResponse
{
    // Validación y actualización
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'category_id' => 'required|exists:categories,id',
        'year' => 'required|integer|min:1900|max:' . date('Y'),
        'price' => 'required|numeric|min:0',
        'stock' => 'required|integer|min:0',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        'description' => 'nullable|string',
    ]);

    $product->update($validated);

    // Redirige a la lista de productos
    return redirect()->route('product.index')->with('success', 'Producto actualizado correctamente.');
}



}
