<?php

namespace App\Http\Controllers;

use App\Repositories\Shop\ShopRepositoryInterface;
use App\Services\Cart;
use App\Traits\CartActions;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;


class CartController extends Controller
{
    use CartActions;
    private ShopRepositoryInterface $repository;
    private Cart $cart;

    public function __construct(ShopRepositoryInterface $repository, Cart $cart)
    {
        $this->repository = $repository;
        $this->cart = $cart;
    }

    public function index(): View
    {      
        return view('cart.index');
    }

    public function increment(): RedirectResponse
    {
        $this->incrementProductQuantify();
        return redirect()->route('cart.index');
    }

    public function decrement(): RedirectResponse
    {
        $this->decrementProductQuantity();
        return redirect()->route('cart.index');
    }

    public function remove(): RedirectResponse
    {
        $this->removeProduct();
        return redirect()->route('cart.index');
    }

    public function clear(): RedirectResponse
    {
        $this->clearCart();
        return redirect()->route('cart.index');
    }

    public function checkout(): View
{
    return view('cart.checkout', ['cart' => $this->cart->getCart()]);
}

public function processPayment(Request $request): RedirectResponse
{
    $request->validate([
        'payment_method' => 'required',
    ]);

    $user = auth()->user();
    $cartTotal = $this->cart->getTotalCost(false);

    // Si el saldo es insuficiente
    if ((int) $user->balance < (int) $cartTotal) {
        return redirect()->route('cart.checkout')->with('error', 'Saldo insuficiente para completar la compra. Tu saldo actual es: $' . number_format($user->balance, 0, ',', '.'));
    }

    // Si el saldo es suficiente, realiza el pago
    $user->balance -= $cartTotal;
    $user->save();

    // Aquí podrías limpiar el carrito si lo deseas
    $this->clearCart();

    return redirect()->route('cart.checkout')->with('success', 'Pago realizado con éxito. Saldo restante: $' . number_format($user->balance, 0, ',', '.'));
}



}
