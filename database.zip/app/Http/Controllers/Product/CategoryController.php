<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Repositories\Category\CategoryRepositoryInterface;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use App\Http\Requests\CategoryRequest;
use App\Models\Category;


class CategoryController extends Controller
{
    private CategoryRepositoryInterface $repository;

    public function __construct(CategoryRepositoryInterface $repository)
    {
        $this->repository = $repository;
    }

    public function index(): View
    {
        // Obtener las categorías paginadas
        $categories = $this->repository->paginate(
            counts: ['products'] // Asegúrate de usar el nombre correcto de la relación
        );

        return view('product.category.index', [
            'categories' => $categories
        ]);
    }

    public function create(): View
    {
        return view('product.category.create', [
            'category' => $this->repository->model(),
            'action' => route('categories.store'),
            'method' => 'POST',
            'submit' => 'Crear',
        ]);
    }

    public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
    ]);

    $imagePath = $request->file('image')->store('categories', 'public');

    Category::create([
        'name' => $request->name,
        'image' => $imagePath, // ✅ Esto queda como "images/nombre.jpg"
    ]);

    return redirect()->route('categories.index')->with('success', 'Categoría creada correctamente.');
}


    public function edit(Category $category): View
    {
        return view('product.category.edit', [
            'category' => $category,
            'action' => route('categories.update', $category),
            'method' => 'PUT',
            'submit' => 'Actualizar',
        ]);
    }
    

public function update(CategoryRequest $request, Category $category): RedirectResponse
{
    $data = $request->validated();

    // Si se subió una nueva imagen
    if ($request->hasFile('image')) {
        // Eliminar la imagen anterior si existe
        if ($category->image && \Storage::disk('public')->exists($category->image)) {
            \Storage::disk('public')->delete($category->image);
        }

        // Subir la nueva imagen
        $data['image'] = $request->file('image')->store('categories', 'public');
    }

    $this->repository->update($data, $category);

    session()->flash('success', 'Categoría actualizada con éxito.');

    return redirect()->route('categories.index');
}

public function destroy(Category $category): RedirectResponse
{
    try {
        $this->repository->delete($category);
        session()->flash('success', 'Categoría eliminada con éxito.');
    } catch (\Exception $exception) {
        session()->flash('error', $exception->getMessage());
    }

    return redirect()->route('categories.index');
}


    

}
