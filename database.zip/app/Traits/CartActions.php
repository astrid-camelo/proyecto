<?php

namespace App\Traits;

use Exception;

trait CartActions
{
    public function addProductToCart(): void
    {
        $productId = request()->input(key: 'product_id');
        $quantity = request()->input(key: 'quantity', default:1);

        $product = $this->repository->find($productId);
        $this->cart->add($product, $quantity);

        session()->flash('success', 'Producto añadido al carrito');
    }

    public function incrementProductQuantify(): void
    {
        $product = $this->repository->find(request(key:'product_id'));
        try {
            $this->cart->increment($product);
            session()->flash('success', 'Cantidad incrementada');
        } catch (Exception $e) {
            session()->flash('error', $e->getMessage());
        }
    }

    public function decrementProductQuantity(): void 
    {
        $this->cart->decrement(request(key: 'product_id'));
        session()->flash('success', 'Cantidad decrementada');
    }

    public function removeProduct(): void 
    {
        $this->cart->remove(request(key: 'product_id'));
        session()->flash('success', 'Producto eliminado del carrito');
    }

    public function clearCart(): void 
    {
        $this->cart->clear();
        session()->flash('success', 'El carrito ha sido vaciado');
    }
}
