<?php

namespace App\Traits;

use NumberFormatter;

trait ProductCurrencyFormatter
{
    public function formatCurrency($value): string
    {
        $formatter = new NumberFormatter(locale: 'es_CO', style: NumberFormatter::CURRENCY);
        return $formatter->formatCurrency($value, currency: 'COP');
    }

}
