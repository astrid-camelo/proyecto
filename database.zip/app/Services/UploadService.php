<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage; // Importa la clase Storage correctamente
use Illuminate\Http\UploadedFile; // Corrige el typo en Illuminate

class UploadService {
    /**
     * Sube un archivo al disco especificado.
     *
     * @param UploadedFile $file
     * @param string $folder
     * @param string $disk
     * @return string
     */
    public static function upload(UploadedFile $file, string $folder, $disk = 'public'): string
    {
        // Corrige el typo en "pathinfo"
        $filename = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $extension = $file->getClientOriginalExtension();
        $filename = $filename . '-' . time() . '.' . $extension;

        // Guarda el archivo en el disco y carpeta especificados
        return $file->storeAs($folder, $filename, $disk);
    }

    /**
     * Elimina un archivo del disco especificado.
     *
     * @param string $path
     * @param string $disk
     * @return bool
     */
    public static function delete(string $path, $disk = 'public'): bool 
    {
        // Verifica si el archivo existe antes de intentar eliminarlo
        if (!Storage::disk($disk)->exists($path)) {
            return false;
        }

        // Elimina el archivo
        return Storage::disk($disk)->delete($path);
    }

    /**
     * Obtiene la URL de un archivo en el disco especificado.
     *
     * @param string $path
     * @param string $disk
     * @return string
     */
    public static function url(string $path, string $disk = 'public'): string 
    {
        return Storage::disk($disk)->url($path);
    }
}
