<?php 

namespace App\Services;

use App\Repositories\Cart\CartRepositoryInterface;
use App\Models\Product; 
use Exception;
use Illuminate\Support\Collection;

final class Cart
{
    private CartRepositoryInterface $repository;

    public function __construct(CartRepositoryInterface $repository)
    {
       
        $this->repository = $repository;
    }

    public function add(Product $product, int $quantify = 1): void 
    {
        $this->repository->add($product, $quantify);
    }

    /** 
     * @throws Exception

    */

    public function increment(Product $product): void
    {
        $this->repository->increment($product);
    }

    public function decrement(int $productId): void 
    {
        $this->repository->decrement($productId);
    }

    public function remove(int $productId): void 
    {
        $this->repository->remove($productId);
    }

    public function clear(): void 
    {
        $this->repository->clear();
    }

    public function getTotalQuantityForProduct(Product $product): int
    {
        return $this->repository->getTotalQuantityForProduct($product);
    }

    public function getTotalCostForProduct(Product $product, bool $formatted = false): float|string
    {
        return $this->repository->getTotalCostForProduct($product, $formatted);
    }

    public function getTotalQuantity(): int
    {
        return $this->repository->getTotalQuantity();
    }

    public function getTotalCost(bool $formatted = false): float|string
    {
        return $this->repository->getTotalCost($formatted);
    }

    public function hasProduct(Product $product): bool
    {
        return $this->repository->hasProduct($product);
    }
    
    public function getCart(): collection
    {
        return $this->repository->getCart();
    }

    public function isEmpty(): bool
    {
        return $this->repository->isEmpty();
    }

}
