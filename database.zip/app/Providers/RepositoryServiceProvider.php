<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repositories\Category\CategoryRepositoryInterface;
use App\Repositories\Category\CategoryRepository;
use App\Repositories\Product\ProductRepositoryInterface;
use App\Repositories\Product\EloquentProductRepository;
use App\Repositories\Cart\CartRepositoryInterface;
use App\Repositories\Shop\ShopRepositoryInterface;
use App\Repositories\Shop\EloquentShopRepository;
use App\Repositories\Cart\SessionCartRepository;


class RepositoryServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(
            CategoryRepositoryInterface::class,
            CategoryRepository::class
        );

        $this->app->bind(
            ProductRepositoryInterface::class,
            EloquentProductRepository::class
        );

        $this->app->bind(
            CartRepositoryInterface::class,
            SessionCartRepository::class
        );

        $this->app->bind(
            ShopRepositoryInterface::class,
            EloquentShopRepository::class
        );
    }

    public function boot()
    {
        //
    }
}
