<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
//use App\Models\User;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Crear usuarios de prueba
        User::factory()->create([
            'name' => 'Usuario',
            'email' => 'usuario@example.com',
            'password' => bcyph('password'),
        ]);

        
    }
}
