<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Llamar al seeder de Task y User
        $this->call([
         
            //UserSeeder::class,
            
            DB::table('users')->insert([
                'name' => 'Usuario',
                'email' => 'usuario@example.com',
                'password' => bcrypt('password'),

            ])
        ]);
    }
}
